from flask import Flask, render_template
from flask_socketio import SocketIO, emit
import threading
from langchain_ollama import OllamaLLM
from TXT_DS_Converser import ConversationHistoryManager
import time

# Initialize the model and conversation history manager
model = OllamaLLM(model="new-dolphin", stream=True)  # Assume the model supports streaming
history_manager = ConversationHistoryManager(conversation_file="conversation_history.txt")

# Initialize the Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

# Handle message from the frontend and generate AI response
@socketio.on('user_message')
def handle_user_message(data):
    user_input = data['message']  # Receive user input from frontend
    context = history_manager.get_formatted_history(user_input)  # Get conversation history
    
    response = ""
    for chunk in model.stream(context):
        response += chunk
        socketio.emit('ollama_response', {'response': response})  # Send the AI response back to the frontend
        time.sleep(0.02)  # Simulate typing delay
    
    # Update conversation history
    history_manager.update_history(user_input, response)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == "__main__":
    socketio.run(app)